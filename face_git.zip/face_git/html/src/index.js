
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'mobx-react';
import 'react-app-polyfill/ie9'; // For IE 9-11 support
import 'react-app-polyfill/stable';
import './polyfill';
import authorizationHeader from './config/auth';
import stores from './stores';
import './index.css';
import App from './App';

authorizationHeader();

ReactDOM.render(
  // eslint-disable-next-line react/jsx-filename-extension
  <Provider {...stores}>
    <App />
  </Provider>, document.getElementById('root'),
);
