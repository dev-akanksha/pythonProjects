import { lazy } from 'react';

const Dashboard = lazy(() => import('./views/Dashboard/Dashboard'));
const CoreUIIcons = lazy(() => import('./views/Icons/CoreUIIcons/CoreUIIcons'));
const Users = lazy(() => import('./views/Users/Users'));
const User = lazy(() => import('./views/Users/User'));
const AddUser = lazy(() => import('./views/AddUser'));
const Attendance = lazy(() => import('./views/Attendance'));

// https://github.com/ReactTraining/react-router/tree/master/packages/react-router-config
const routes = [
  { path: '/', exact: true, name: 'Home' },
  { path: '/dashboard', name: 'Dashboard', component: Dashboard },
  { path: '/icons', exact: true, name: 'Icons', component: CoreUIIcons },
  { path: '/icons/coreui-icons', name: 'CoreUI Icons', component: CoreUIIcons },
  { path: '/users', exact: true, name: 'Users', component: Users },
  { path: '/users/:id', exact: true, name: 'User Details', component: User },
  { path: '/add-user', exact: true, name: 'User Details', component: AddUser },
  { path: '/edit/:id/', exact: true, name: 'User Details', component: AddUser },
  { path: '/attendance/', exact: true, name: 'User Details', component: Attendance },

];

export default routes;
