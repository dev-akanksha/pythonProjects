import { observable } from 'mobx';

class LoginStore {
    @observable formSubmitted = false;
    @observable username = '';
    @observable password = '';
}

export default LoginStore;
