import React, { Component } from 'react';
import { observer } from 'mobx-react';
import {
  Button,
  Card,
  CardBody,
  CardGroup,
  Col,
  Container,
  Form,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Row,
  FormFeedback,
} from 'reactstrap';
import Store from './store';

@observer
class Login extends Component {
  // static proptypes = {
  //   history: Proptypes.
  // }

  constructor() {
    super();
    this.store = new Store();
  }

  /** login functionality */
  loginHandler = (event) => {
    const { username, password } = this.store;
    event.preventDefault();
    this.store.formSubmitted = true;

    if (username === 'admin' && password === 'foo') {
      this.props.history.push('/dashboard');
    }
  };

  /** */
  handleChange = (event, index) => {
    const { target } = event;

    if (index === 1) {
      this.store.username = target.value;
    } else {
      this.store.password = target.value;
    }
  }

  render() {
    const { formSubmitted, username, password } = this.store;
    return (
      <div className="app flex-row align-items-center">
        <Container>
          <Row className="justify-content-center">
            <Col md="5">
              <CardGroup>
                <Card className="p-4">
                  <CardBody>
                    <Form onSubmit={this.loginHandler}>
                      <h1>Login</h1>
                      <p className="text-muted">Sign In to your account</p>
                      <InputGroup className="mb-3">
                        <InputGroupAddon addonType="prepend">
                          <InputGroupText>
                            <i className="icon-user" />
                          </InputGroupText>
                        </InputGroupAddon>
                        <Input
                          type="text"
                          placeholder="Username"
                          autoComplete="username"
                          name="username"
                          invalid={formSubmitted && username === ''}
                          value={username}
                          onChange={event => this.handleChange(event, 1)}
                        />
                      </InputGroup>
                      <InputGroup className="mb-4">
                        <InputGroupAddon addonType="prepend">
                          <InputGroupText>
                            <i className="icon-lock" />
                          </InputGroupText>
                        </InputGroupAddon>
                        <Input
                          type="password"
                          name="password"
                          placeholder="Password"
                          autoComplete="current-password"
                          invalid={formSubmitted && password === ''}
                          value={password}
                          onChange={event => this.handleChange(event, 2)}
                        />
                        <Input
                          type="hidden"
                          invalid={(username !== '' && username !== 'admin')
                           || (password !== '' && password !== 'foo')}
                        />
                        {
                            (username !== 'admin' || password !== 'foo') &&
                              <FormFeedback invalid>
                                {'Username or Password is wrong'}
                              </FormFeedback>
                          }
                      </InputGroup>
                      <Row>
                        <Col xs="12" className="text-right">
                          <Button
                            type="submit"
                            color="primary"
                            className="px-4"
                          >
                            Login
                          </Button>
                        </Col>
                      </Row>
                    </Form>
                  </CardBody>
                </Card>
              </CardGroup>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default Login;
