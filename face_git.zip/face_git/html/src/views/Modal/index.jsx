import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

class Confirmation extends Component {
  static propTypes = {
    onHide: PropTypes.func.isRequired,
    data: PropTypes.object.isRequired,
    show: PropTypes.bool.isRequired,
  };

  render() {
    const { onHide, data, show } = this.props;
    const closeBtn = <button className="close" onClick={onHide}>&times;</button>;
    return (
      <div>
        <Modal isOpen={show} >
          <ModalHeader close={closeBtn}>{data.title}</ModalHeader>
          <ModalBody>
            {data.message}
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={event => onHide(event, 1)}>Yes</Button>{' '}
            <Button color="secondary" onClick={onHide}>Cancel</Button>
          </ModalFooter>
        </Modal>
      </div>
    );
  }
}

export default Confirmation;
