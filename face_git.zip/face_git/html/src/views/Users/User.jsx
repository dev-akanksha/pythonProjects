/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable no-nested-ternary */
import React, { Component } from 'react';
import { observer } from 'mobx-react';
import PropTypes from 'prop-types';
import { toJS } from 'mobx';
import { Card, CardBody, CardHeader, Col, Row, Table } from 'reactstrap';
import Slider from 'react-slick';
import noImage from '../../assets/img/no-image-small.png';
import Store from './store';
import { BASE } from '../../config/constant';

@observer
class User extends Component {
  static propTypes = {
    match: PropTypes.object.isRequired,
  }

  constructor() {
    super();
    this.store = new Store();
  }

  componentDidMount() {
    const id = this.props.match.params.id;

    this.store.getUserDetail(id);
  }

  render() {
    console.log(this.store);
    const { user, currentImage } = this.store;
    const userInfo = user.Item ? user.Item.info : {};
    const userData = userInfo.userDetails ? JSON.parse(userInfo.userDetails) : '';
    const userAttendance = user.Item ? user.Item.attendance : {};
    console.log(userAttendance);
    const imagePath = userInfo.s3Url;
    //const currentImage = imagePath || image;


    const userDetails = userData;
    console.log(userDetails);

    return (
      <div className="animated fadeIn">
        <Row>
          <Col lg={6}>
            <Card>
              <CardHeader>
                <i className="fa fa-file-image-o" /> Employee Photo
              </CardHeader>
              <CardBody>
                <Col sm={12} className="d-flex user-image-box justify-content-center">
                  {!imagePath ?
                    <img
                      src={noImage}
                      className="img-avatar"
                      alt={'no image'}
                    />
                   :
                    <img
                      src={`${imagePath}?${Math.random()}`}
                      alt={userDetails.firstName}
                    />}
                </Col>

                <Col />
              </CardBody>
            </Card>
          </Col>
          <Col lg={6}>
            <Card>
              <CardHeader>
                <strong>
                  <i className="icon-info pr-1" />User id:{' '}
                  {this.props.match.params.id}
                </strong>
              </CardHeader>
              <CardBody>
                <Table responsive striped hover>
                  <tbody>
                    {userDetails.empId ?
                      <React.Fragment>
                        <tr key={'empId'}>
                          <td>{'Employee Id'}</td>
                          <td><strong>{userDetails.empId}</strong></td>
                        </tr>
                        <tr key={'firstName'}>
                          <td>{'First Name'}</td>
                          <td><strong>{userDetails.firstName}</strong></td>
                        </tr>
                        <tr key={'lastName'}>
                          <td>{'Last Name'}</td>
                          <td><strong>{userDetails.lastName}</strong></td>
                        </tr>
                        <tr key={'emailId'}>
                          <td>{'Email Id'}</td>
                          <td><strong>{userDetails.emailId}</strong></td>
                        </tr>
                        <tr key={'dateOfBirth'}>
                          <td>{'dateOfBirth'}</td>
                          <td><strong>{userDetails.dateOfBirth}</strong></td>
                        </tr>
                        <tr key={'fathersName'}>
                          <td>{'Father Name'}</td>
                          <td><strong>{userDetails.fathersName}</strong></td>
                        </tr>
                        <tr key={'gender'}>
                          <td>{'Gender'}</td>
                          <td><strong>{userDetails.gender}</strong></td>
                        </tr>
                        <tr key={'contactNo'}>
                          <td>{'Contact No'}</td>
                          <td>
                            <strong>{userDetails.contactNo}</strong>
                          </td>
                        </tr>
                        <tr key={'nationality'}>
                          <td>{'Nationality'}</td>
                          <td>
                            <strong>{userDetails.nationality}</strong>
                          </td>
                        </tr>
                        <tr key={'designation'}>
                          <td>{'Designation'}</td>
                          <td>
                            <strong>{userDetails.designation}</strong>
                          </td>
                        </tr>
                        <tr key={'role'}>
                          <td>{'Role'}</td>
                          <td>
                            <strong>{userDetails.role }</strong>
                          </td>
                        </tr>
                        {
                          userAttendance &&
                          <tr key={'attendance'}>
                            <td>{'Attendance'}</td>
                            <td>
                            <table>
                                <tr><th>{`Date`}</th>
                                <th>{`In Time`}</th>
                                <th>{`Out Time`}</th>
                                </tr>
                              {
                              (userAttendance && userAttendance.length > 0) &&
                              userAttendance.map(data => (
                                  <tr>
                                  <td>{data.date}</td>
                                  <td>{data.intime}</td>
                                  <td>{data.outtime}</td>
                                  </tr>
                              ))
                          }
                                                        </table>

                            </td>
                          </tr>
                        }
                      </React.Fragment>
                  :
                      <tr key={'role'}>
                        <td colSpan="2">{'No record found'}</td>
                      </tr>
                  }
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default User;
