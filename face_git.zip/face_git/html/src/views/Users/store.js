import { observable, action, computed } from 'mobx';
import { getUserData, deleteUser, updateUser, getUserDataById,
} from '../../services/CommonService';
import { notificationAlert } from '../../services/UtilityService';


class AddUserStore {
  @observable usersData = [];
  @observable isDeleted = false;
  @observable setModalData = {};
  @observable showModal = false;
  @observable currentId = 0;
  @observable currentImage = '';
  @observable modalProps = {
    title: '',
    message: '',
  }
  @observable user = {};

    @computed get showHideModal() {
      return this.showModal;
    }

  set showHideModal(val) {
    this.showModal = val;
    if (!val) {
      this.modalProps.title = '';
      this.modalProps.message = '';
    }
  }

  @action setModalDataObj(user) {
    this.setModalData = user;
  }

  @action getUsersList() {
    getUserData().then((result) => {
      console.log(result)
      if (result) 
        {
        //   result.messageList.map((k) => {
        //   console.log(k)

        //   result[k.info.userDetail].id = k.info.userDetail;
        //   console.log(result)
        //   return result[k];
        // });

        this.usersData = JSON.parse(result.messageList);
       

      }
    });
  }


  // delete user
  @action deleteUser() {
    this.loader = true;
    const user = this.setModalData;

    deleteUser(user.empId).then((result) => {
      if (result) {
        this.isDeleted = false;
        this.showHideModal = false;
        this.getUsersList();
        notificationAlert(result.messageList, result.messageList);
      }
    });
  }

  // change user status
  @action changeStatus() {
    this.loader = true;
    const user = this.setModalData;

    if (user.status) {
      user.status = false;
    } else {
      user.status = true;
    }

    updateUser(user, user.id).then((result) => {
      if (result) {
        this.isDeleted = false;
        this.showHideModal = false;
        this.getUsersList();
        notificationAlert('Status Changed Successfully', 'success');
      }
    });
  }

   /** user details */
   @action getUserDetail(id) {
     getUserDataById(id).then((result) => {
        //console.log(result)
       if (result) {
         this.user = JSON.parse(result.messageList);
       }
     });
   }
}

export default AddUserStore;
