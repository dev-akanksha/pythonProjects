import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { observer } from 'mobx-react';
import PropTypes from 'prop-types';
import { Card, CardBody, CardHeader, Col, Row, Table } from 'reactstrap';
import Confirmation from '../Modal';
import Store from './store';
import image from '../../assets/img/avatars/1.jpg';
import { BASE } from '../../config/constant';


const UserRow = (props) => {
  const userJSON = props.user;
  const user = JSON.parse(userJSON.userDetails);
  const imagePath = userJSON.s3Url;
   user.img_path = imagePath || image;

    console.log(imagePath)

  const userLink = `/users/${user.empId}`;
  const editUserLink = `/edit/${user.empId}/`;
  const userAttendance = user.attendance ? user.attendance[user.attendance.length - 1] : [];

  return (
    <tr key={`${user.empId}_child`}>
      <td className="text-center">
        <div className="avatar">
          <Link to={userLink}>
            {user.img_path ? <img
              src={user.img_path !== '' && `${user.img_path}?${Math.random()}`}
              className="img-avatar"
              alt={user.name}
            /> :
            <img
              src={image}
              className="img-avatar"
              alt={user.name}
            />
            }
            <span className="avatar-status badge-success" />
          </Link>
        </div>
      </td>
      <td>
        <Link to={userLink}>{user.empId}</Link>
      </td>
      <td>
        <div>
          <Link to={userLink}>{`${user.firstName} ${user.lastName}`}</Link>
        </div>
        {userAttendance && userAttendance.length > 0 &&
          <div className="small text-muted">Last Login: {new Date(userAttendance).toLocaleString()}</div>
        }
      </td>
      <td>{user.role}</td>
      <td>{user.contactNo}</td>
      <td>{user.gender ? user.gender : 'Male'}</td>
      <td>{user.status ? 'Active' : 'Inactive'}</td>
      <td className="action-button">
        <Link to={editUserLink} className="btn btn-link btn-edit">
          <i className="fa fa-pencil" />Edit</Link>
        {/* {user.status ?
          <button className="btn btn-link btn-deactivate" onClick={() => props.handleStatus(user)}>
            <i className="fa cui-circle-x" />Deactivate</button>
        :
          <button className="btn btn-link btn-active" onClick={() => props.handleStatus(user)}>
            <i className="fa cui-circle-check" />Activate</button>
        } */}
        <button className="btn btn-link btn-delete" onClick={() => props.handleDelete(user)}>
          <i className="fa fa-trash" />Delete</button>
      </td>
    </tr>
  );
};

UserRow.propTypes = {
  handleStatus: PropTypes.func.isRequired,
  handleDelete: PropTypes.func.isRequired,
};

@observer
class Users extends Component {
  static propTypes = {
    dashboard: PropTypes.string.isRequired,
  }

  constructor() {
    super();

    this.store = new Store();
  }


  componentDidMount() {
    this.store.getUsersList();
  }


  // delete user
  handleDelete = (user) => {
    this.store.isDeleted = true;
    this.store.setModalDataObj(user);
    this.store.showHideModal = true;
    this.store.modalProps.title = 'Delete User Confirmation';
    this.store.modalProps.message = 'Are you sure you want to delete this User?';
  }

  // change status
  handleStatus = (user) => {
    this.store.setModalDataObj(user);
    this.store.showHideModal = true;
    this.store.modalProps.title = 'Change User Status';
    this.store.modalProps.message = 'Are you sure you want to change status of this User?';
  }

  // hide confirmation modal
  closeConfirmation = (e, val) => {
    if (val === 1) {
      if (this.store.isDeleted) {
        this.store.deleteUser();
      } else {
        this.store.changeStatus();
      }
    } else {
      this.store.showHideModal = false;
      this.store.isDeleted = false;
    }
  }

  render() {
    const { usersData, showModal } = this.store;
     console.log(usersData);
    let userList = usersData;
    const { dashboard } = this.props;

    if (dashboard === 'dashboard') {
      userList = userList.slice(0, 8);
    }

    return (
      <div className="animated fadeIn">
        <Row>
          <Confirmation
            show={showModal}
            onHide={this.closeConfirmation}
            data={this.store.modalProps}
          />
          <Col xl={12}>
            <Card>
              <CardHeader>
                <i className="fa fa-users" /> Employee{' '}
                <small className="text-muted">
                  list of all employees added to the system
                </small>
              </CardHeader>
              <CardBody>
                <Table responsive hover>
                  <thead>
                    <tr>
                      <th scope="col" className="text-center">
                        <i className="icon-people" />
                      </th>
                      <th scope="col">Emp Id</th>
                      <th scope="col">Name</th>
                      <th scope="col">role</th>
                      <th scope="col">Contact No</th>
                      <th scope="col">Gender</th>
                      <th scope="col">Status</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {userList.map(user => (
                      user.empId && <UserRow
                        key={user.empId}
                        user={user.info}
                        handleDelete={this.handleDelete}
                        handleStatus={this.handleStatus}
                      />
                    ))}
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default Users;
