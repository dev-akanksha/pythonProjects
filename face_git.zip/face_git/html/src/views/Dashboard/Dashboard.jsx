import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import {
  Button,
  Card,
  CardBody,
  Col,
  Row,
} from 'reactstrap';

import Users from '../Users/Users';

class Dashboard extends Component {

  loading = () => (
    <div className="animated fadeIn pt-1 text-center">Loading...</div>
  );

  render() {
    return (
      <div className="animated fadeIn">
        <Row>
          <Col>
            <Card>
              <CardBody>
                <h1>Welcome <strong>Admin</strong>!</h1>
                <br />
                <p>
                 Attendance application.
                </p>
                <br />
                <br />

                <Users dashboard={'dashboard'} />
                <Link to="/users">
                  <Button
                    className="btn btn-link float-right btn-more"
                  >
                    View all users...
                  </Button>
                </Link>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default Dashboard;
