import { observable, action, toJS } from 'mobx';
import { postData, getUserDataById, getUserPhoto, updateUser, updateUserPhoto, imageCapture } from '../../services/CommonService';
import { notificationAlert, isEmail } from '../../services/UtilityService';
import { BASE } from '../../config/constant';

class AddUserStore {
  @observable formSubmitted = false;
  @observable isEdit = false;
  @observable isNotPhotoValid = false;
  @observable currentId = 0;
  @observable userField = {
    empId: '',
    firstName: '',
    lastName: '',
    fathersName: '',
    emailId: '',
    dateOfBirth: '',
    nationality: '',
    gender: '',
    contactNo: '',
    designation: '',
    businessUnit: '',
    role: '',
    skypeId: '',
    twitter: '',
    linkedIn: '',
    status: true,
    isDeleted: false,
    img_path: '',
  }
  @observable validEmail = false;
  @observable showLoader = false;

  // set user data to user object
  @observable setUserData(user) {
    this.userField[user.name] = user.name === 'status' ? user.checked : user.value;
  }

  @action submitUserData() {
    this.formSubmitted = true;
    const { empId, firstName, lastName, emailId } = this.userField;
    this.validEmail = isEmail(emailId);
    
    if (empId !== '' && firstName !== '' && lastName !== '' && emailId !== '') {
      this.showLoader =true;
        const data = { ...toJS(this.userField) };
        if (!this.isEdit) {        
            postData(data).then((result) => {
              this.showLoader = false;
                if (result.message == 'success') {
                    this.clearToDefaultValue();
                    notificationAlert(result.messageList, 'success');
                } else {
                    notificationAlert(result.messageList, 'error');
                }
            });
        } else {
            updateUser(data, this.currentId).then((result) => {
              this.showLoader = false;
                if (result.message == 'success') {
                    notificationAlert(result.messageList, 'success');
                } else {
                    notificationAlert(result.messageList, 'error');
                }
            });
        }
    }
  }

  /** user details */
  @action getUserDetail(id) {
    getUserDataById(id).then((result) => {
      if (result) {
        const user = JSON.parse(result.messageList);
        const { userDetails } = user.Item.info;
        const { s3Url } = user.Item.info;
        const details = JSON.parse(userDetails);
        this.userField = {
          ...details,
          img_path: s3Url,
          img_captured:0
        }

        console.log(this.userField);

      }
    });
  }

  /** take user photo */
  @action async takeUserPhoto(id) {
    const data = { ...toJS(this.userField) };
    data.isEdit = this.isEdit;
    this.userField.img_captured = 0;
    imageCapture(data).then((result) => {
      if (result) {
        if (result.message == 'success') {
          const img_path = result.messageList[0];
          const userPath = this.userField;
          userPath.img_path = img_path;
          this.userField = {...this.userField, userPath};
          this.userField.img_captured = 1;
          notificationAlert(result.messageList, 'success');
        } else {
          notificationAlert(result.messageList, 'error');
        }
      }
    });

    // const userAPI = await postData(this.userField);
    // if (userAPI) {
    //   const userId = Object.entries(userAPI)[0];
    //   this.currentId = userId[0];
    //   this.isEdit = true;
    // }
    //}

    // const data = {
    //   empId: this.currentId,
    //   firstName: this.userField.firstName,
    // };

    // if (this.isEdit && id) {
    //   const responseOne = await updateUserPhoto(data);
    //   if (responseOne) {
    //     this.getUserDetail(this.currentId);
    //   }
    // } else {
    //   const response = await getUserPhoto(data);
    //   if (response) {
    //     this.getUserDetail(this.currentId);
    //   }
    // }
  }

  /**
   * clear data
   */
  @action clearToDefaultValue() {
    this.userField = {
      empId: '',
      firstName: '',
      lastName: '',
      fathersName: '',
      emailId: '',
      dateOfBirth: '',
      nationality: '',
      gender: '',
      contactNo: '',
      designation: '',
      businessUnit: '',
      role: '',
      skypeId: '',
      twitter: '',
      linkedIn: '',
      status: true,
      isDeleted: false,
    };
    this.formSubmitted = false;
  }

  @action showErrorNotification() {
    this.isNotPhotoValid = true;
    notificationAlert('Employee Id and Email Id required!', 'error');
  }
}

export default AddUserStore;
