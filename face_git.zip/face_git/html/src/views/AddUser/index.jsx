import React, { Component } from 'react';
import { observer, PropTypes } from 'mobx-react';
import { toJS } from 'mobx';
import {
  Card,
  CardBody,
  CardHeader,
  Col,
  Row,
  Button,
  Form,
  FormGroup,
  Label,
  Input,
  FormFeedback,
  Spinner
} from 'reactstrap';
import Slider from 'react-slick';
import { ROLES as roles, BASE } from '../../config/constant';
import Store from './store';
import noImage from '../../assets/img/no-image-small.png';


@observer
class AddUser extends Component {

  static propTypes = {
    match: PropTypes.objectOrObservableObject.isRequired,
  }

  /** calls before mounting of class */
  constructor() {
    super();

    this.store = new Store();
  }

  componentDidMount() {
    const { match } = this.props;
    if (match.params.id) {
      this.store.isEdit = true;
      this.store.currentId = match.params.id;
      this.store.getUserDetail(match.params.id);
    }
  }

  /** common function to get all input values */
  handleChange = (e) => {
    this.store.setUserData(e.target);
  }

  /** add or update employee */
  addOrUpdateEmployee = (event) => {
    event.preventDefault();
    this.store.submitUserData();
  }

  takeUserPhoto = () => {
    const { match } = this.props;
    const { userField } = this.store;
    if (match.params.id) {
      this.store.isEdit = true;
      this.store.currentId = match.params.id;
    }

    if (userField.empId !== '' && userField.emailId !== '') {
      this.store.isNotPhotoValid = false;
      this.store.takeUserPhoto(match.params.id);
    } else {
      this.store.showErrorNotification();
    }
  }

  render() {
    const {
      userField: {
          empId,
          firstName,
          lastName,
          fathersName,
          emailId,
          dateOfBirth,
          nationality,
          gender,
          contactNo,
          designation,
          role,
          skypeId,
          img_path: imagePath,
          img_captured
      },
      isNotPhotoValid,
      formSubmitted,
      validEmail,
      isEdit,
      showLoader,      
    } = this.store;


    const imgPath = toJS(imagePath);

    return (
      <div className="animated fadeIn">
        <Row>
          {showLoader && <div className="loader-overlay"><Spinner color="light" /></div>}
          <Col xl={6}>
            <Card>
              <CardHeader>
                <i className="fa fa-file-image-o" /> Employee Photo
              </CardHeader>
              <CardBody>
                <Col sm={12} className="user-image-box">
                  {imgPath ? 
                  isEdit ?
                  <img
                    src={imgPath !== '' && `${imgPath}?${Math.random()}`}
                    alt=""
                  /> :
                  <img
                    src={imgPath !== '' && `${BASE}${imgPath}`}
                    alt=""
                  /> :
                  <img src={noImage} alt="" />
              }
                </Col>
                <Col sm={12} className="text-center ">
                  <button className="btn btn-primary" onClick={this.takeUserPhoto}>
                    Take Photo
                  </button>
                </Col>
                <Col />
              </CardBody>
            </Card>
          </Col>
          <Col xl={6}>
            <Card>
              <CardHeader>
                <i className="fa fa-user-plus" />Add Employee Details
              </CardHeader>
              <CardBody>
                <Form onSubmit={this.addOrUpdateEmployee}>
                  <FormGroup row>
                    <Label for="empId" sm={3}>Employee ID</Label>
                    <Col sm={9}>
                      <Input
                        type="input"
                        name="empId"
                        placeholder=""
                        onChange={this.handleChange}
                        invalid={formSubmitted && empId === ''}
                        className={isNotPhotoValid ? 'red-border' : ''}
                        value={empId}
                        maxLength="5"
                      />
                    </Col>
                  </FormGroup>
                  <FormGroup row>
                    <Label for="name" sm={3}>
                      Name
                    </Label>
                    <Col sm={9}>
                      <Row>
                        <Col sm={6}>
                          <Input
                            type="input"
                            name="firstName"
                            id="firstName"
                            placeholder="First Name"
                            onChange={this.handleChange}
                            invalid={(formSubmitted && firstName === '')}
                            className={isNotPhotoValid ? 'red-border' : ''}
                            value={firstName}
                          />
                        </Col>
                        <Col sm={6}>
                          <Input
                            type="input"
                            name="lastName"
                            placeholder="Last Name"
                            onChange={this.handleChange}
                            invalid={formSubmitted && lastName === ''}
                            value={lastName}
                          />
                        </Col>
                      </Row>
                    </Col>
                  </FormGroup>
                  <FormGroup row>
                    <Label for="email" sm={3}>
                      Email
                    </Label>
                    <Col sm={9}>
                      <Input
                        type="email"
                        name="emailId"
                        placeholder=""
                        onChange={this.handleChange}
                        invalid={formSubmitted && (emailId === '' || !validEmail)}
                        value={emailId}
                      />
                      <FormFeedback invalid={formSubmitted && (emailId === '' || !validEmail)}>
                        {'Please enter valid email'}
                      </FormFeedback>
                    </Col>
                  </FormGroup>
                  <FormGroup row>
                    <Label for="fathersName" sm={3}>
                      Father Name
                    </Label>
                    <Col sm={9}>
                      <Input
                        type="input"
                        name="fathersName"
                        id="exampleEmail1"
                        placeholder=""
                        onChange={this.handleChange}
                        value={fathersName}
                      />

                    </Col>
                  </FormGroup>
                  <FormGroup row>
                    <Label for="dateOfBirth" sm={3}>
                      Date of Birth
                    </Label>
                    <Col sm={9}>
                      <Input
                        type="date"
                        name="dateOfBirth"
                        placeholder=""
                        onChange={this.handleChange}
                        value={dateOfBirth}
                      />
                    </Col>
                  </FormGroup>

                  <FormGroup row>
                    <Label for="nationality" sm={3}>
                      Nationality
                    </Label>
                    <Col sm={9}>
                      <Input
                        type="input"
                        name="nationality"
                        placeholder=""
                        onChange={this.handleChange}
                        value={nationality}
                      />
                    </Col>
                  </FormGroup>
                  <FormGroup row>
                    <Label for="gender" sm={3}>
                      Gender
                    </Label>
                    <Col sm={9}>
                      <Input
                        type="select"
                        name="gender"
                        id="exampleSelect"
                        onChange={this.handleChange}
                        value={gender}
                      >
                        <option>Select</option>
                        <option>Male</option>
                        <option>Female</option>
                      </Input>
                    </Col>
                  </FormGroup>
                  <FormGroup row>
                    <Label for="contactNo" sm={3}>
                      Contact No
                    </Label>
                    <Col sm={9}>
                      <Input
                        type="input"
                        name="contactNo"
                        id="contactNo"
                        placeholder=""
                        onChange={this.handleChange}
                        value={contactNo}
                      />
                    </Col>
                  </FormGroup>
                  <FormGroup row>
                    <Label for="designation" sm={3}>
                      Designation
                    </Label>
                    <Col sm={9}>
                      <Input
                        type="input"
                        name="designation"
                        id="designation"
                        placeholder=""
                        onChange={this.handleChange}
                        value={designation}
                      />
                    </Col>
                  </FormGroup>

                  <FormGroup row>
                    <Label for="role" sm={3}>
                      Role
                    </Label>
                    <Col sm={9}>
                      <Input
                        type="select"
                        name="role"
                        id="role"
                        onChange={this.handleChange}
                        value={role}
                      >
                        <option>Select role</option>
                        {
                          roles.map(roleItem => (
                            <option key={roleItem} value={roleItem}>{roleItem}</option>
                          ))
                        }
                      </Input>
                    </Col>
                  </FormGroup>

                  <FormGroup row>
                    <Label for="skypeId" sm={3}>
                      SkypeID
                    </Label>
                    <Col sm={9}>
                      <Input
                        type="input"
                        name="skypeId"
                        placeholder=""
                        onChange={this.handleChange}
                        value={skypeId}
                      />
                    </Col>
                  </FormGroup>
                  <FormGroup row>
                    <Label for="skypeID" sm={3} />
                    <Col sm={9}>
                      <Button type="submit">Submit</Button>
                    </Col>
                  </FormGroup>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default AddUser;
