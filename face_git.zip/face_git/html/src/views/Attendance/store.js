import { observable, action } from 'mobx';
import { recognizeUser } from '../../services/CommonService';
import { notificationAlert, isEmail } from '../../services/UtilityService';

class AttendanceStore {
    @observable user;

     @action async recognizeUser(prop) {
       recognizeUser().then((result) => {
         	console.log(result);
	        if (result.message == 'success') {
	          notificationAlert(result.messageList, 'success');
            prop.history.push('/dashboard');

	        } else {
	          notificationAlert(result.messageList, 'error');
	        }
       });
       
     }
}

export default AttendanceStore;
