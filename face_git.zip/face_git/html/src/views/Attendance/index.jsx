import React, { Component } from 'react';
import Store from './store';

class Attendance extends Component {
  constructor() {
    super();
    this.store = new Store();
  }

  componentDidMount() {
    this.store.recognizeUser(this.props);
  }

 

  render() {
    return (
      <div>You are now logged in</div>
    );
  }
}

export default Attendance;
