import Page404 from './Page404';
import Page500 from './Page500';

export {
   Page404, Page500,
};
