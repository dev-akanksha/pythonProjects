
class UserStore {

}
export default UserStore;
