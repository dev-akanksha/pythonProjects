import UserStore from './User';

const stores = {
  userStore: new UserStore(),
};

export default stores;
