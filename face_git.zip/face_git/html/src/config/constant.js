
export const BASE = 'http://localhost:5000/';
export const BASE_PATH = 'http://localhost:8000/dataset/';
export const ADD_USER = `${BASE}api/createUser/`;
export const TAKE_USER_IMAGE = `${BASE}api/imageCapture/`;
export const EDIT_USER = `${BASE}api/editUser/`;
export const DELETE_USER = `${BASE}api/deleteUser/`;
export const GET_USER = `${BASE}api/getUserDataById/`;
export const GET_ALL_USERS = `${BASE}api/getAllUsers/`;
export const GET_USER_PHOTO = `${BASE}user_data/`;
export const RECOGNIZE_USER = `${BASE}api/recognize/`;
export const ACTIVATE_USER = `${BASE}activate/`;
export const DISK_USAGE = `${BASE}disk_info/`;


export const ROLES = ['App. Support Eng.',
  'Audio Engineer',
  'Business Analyst',
  'Cloud Engineer',
  'CQA',
  'Delivery Manager - Delivery',
  'Delivery Manager - Design',
  'Designer - HTML',
  'Designer - Web/Graphics',
  'Developer - AngularJS',
  'Developer - BI',
  'Developer - Dot Net',
  'Developer - Flash',
  'Developer - HTML',
  'Developer - Java',
  'Developer - MEAN',
  'Developer - PHP',
  'Developer - SQL',
  'Developer - VC++',
  'Developer-Storyline',
  'DevOps Engineer',
  'Editors',
  'Enterprise Sales Representative',
  'Executive Trainee - Cloud Services',
  'ID',
  'Lead - Design',
  'Lead - Dot Net',
  'Lead - Graphics',
  'Lead - HTML',
  'Lead - ID',
  'Lead - Java',
  'Lead - PDE',
  'Lead - PHP',
  'Lead Business Analyst',
  'Leadership',
  'Learning Strategist',
  'Learning Talent',
  'Manager - PPM',
  'Mobisode Designer',
  'Onsite ID',
  'Onsite Lead ID',
  'PDE',
  'Product Developer',
  'Python Developer',
  'QA - E-learning',
  'QA - Tech',
  'Trainee ID'];
