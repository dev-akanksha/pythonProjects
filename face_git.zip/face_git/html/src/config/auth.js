import axios from 'axios';

const authorizationHeader = () => {
  const ENCODED_STRING = btoa('admin:foo');
  axios.defaults.headers.common.Authorization = `Basic ${ENCODED_STRING}`;
};

export default authorizationHeader;
