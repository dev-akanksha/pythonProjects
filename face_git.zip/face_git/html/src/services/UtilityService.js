import Noty from 'noty';

export const notificationAlert = (msg, type) => new Noty({
  type,
  text: msg,
  timeout: 2000,
  layout: 'topRight',
  theme: 'metroui',
}).show();


export const isEmail = (email = null) => {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
};
