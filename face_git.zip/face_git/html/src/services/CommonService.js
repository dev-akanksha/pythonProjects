import axios, { get, put, post } from 'axios';
import {
  ADD_USER,
  TAKE_USER_IMAGE,
  EDIT_USER,
  DELETE_USER,
  GET_USER,
  GET_ALL_USERS,
  GET_USER_PHOTO,
  RECOGNIZE_USER,
  ACTIVATE_USER,
  DISK_USAGE,
} from '../config/constant';

/** Get all data from storage */
export const getUserData = () =>
  new Promise((resolve, reject) => {
    get(`${GET_ALL_USERS}`)
      .then(result => resolve(result.data))
      .catch(() => reject());
  });

/** Get data by Id from storage */
export const getUserDataById = id =>
  new Promise((resolve, reject) => {
    get(`${GET_USER}${id}`)
      .then(result => resolve(result.data))
      .catch(() => reject());
  });


/** Update data into storage */
export const updateUser = (userData, empId) =>
  new Promise((resolve, reject) => {
    const config = {
      dataType: 'json',
    };
    put(`${EDIT_USER}${empId}`, userData, config)
      .then(result => resolve(result.data))
      .catch(() => reject());
  });

/** Post data into storage */
export const postData = userData =>
  new Promise((resolve, reject) => {
    const config = {
      dataType: 'json',
    };
    console.log(userData);
    post(`${ADD_USER}`, userData, config)
      .then(result => resolve(result.data))
      .catch((error) => { console.log(error); reject(); });
  });

/** Take image*/
export const imageCapture = userData =>
  new Promise((resolve, reject) => {
    const config = {
      dataType: 'json',
    };
    console.log(userData);
    post(`${TAKE_USER_IMAGE}`, userData, config)
      .then(result => resolve(result.data))
      .catch((error) => { console.log(error); reject(); });
  });
/** Delete data into storage */
export const deleteUser = empId =>
  new Promise((resolve, reject) => {
    const config = {
      dataType: 'json',
    };

    axios.delete(`${DELETE_USER}${empId}/`, config)
      .then(result => resolve(result.data))
      .catch(() => reject());
  });

  /** get user photo */
export const getUserPhoto = data =>
new Promise((resolve, reject) => {
  const config = {
    dataType: 'json',
  };
  post(`${GET_USER_PHOTO}`, data, config)
    .then(result => resolve(result.data))
    .catch(() => reject());
});

/** get user photo */
export const updateUserPhoto = data =>
new Promise((resolve, reject) => {
  const config = {
    dataType: 'json',
  };
  put(`${GET_USER_PHOTO}`, data, config)
    .then(result => resolve(result.data))
    .catch(() => reject());
});

/** get user photo */
export const recognizeUser = () =>
new Promise((resolve, reject) => {
  get(`${RECOGNIZE_USER}`)
    .then(result => resolve(result.data))
    .catch(() => reject());
});

/** get user photo */
export const activateUser = () =>
new Promise((resolve, reject) => {
  get(`${ACTIVATE_USER}`)
    .then(result => resolve(result.data))
    .catch(() => reject());
});

/** get user photo */
export const getDiskUsage = () =>
new Promise((resolve, reject) => {
  get(`${DISK_USAGE}`)
    .then(result => resolve(result.data))
    .catch(() => reject());
});
