export default {
  items: [
    {
      name: 'Dashboard',
      url: '/dashboard',
      icon: 'icon-speedometer',
    },
    {
      name: 'Add Employee',
      url: '/add-user',
      icon: 'icon-user-follow',
    },
    {
      name: 'Employee List',
      url: '/users',
      icon: 'icon-user',
    },
    {
      name: 'Attendance',
      url: '/attendance',
      icon: 'icon-calendar',
    },
  ],
};
