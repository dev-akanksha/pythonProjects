import React, { Component } from 'react';

const defaultProps = {};

class DefaultFooter extends Component {
  render() {
    return (
      <React.Fragment>
        <span className="ml-auto"> &copy; 2019
        <a href="https://www.infoprolearning.com/"> Infopro Learning</a>, Inc. All rights reserved.</span>
      </React.Fragment>
    );
  }
}

DefaultFooter.defaultProps = defaultProps;

export default DefaultFooter;
