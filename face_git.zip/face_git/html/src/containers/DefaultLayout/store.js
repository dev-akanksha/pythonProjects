
import { observable, action } from 'mobx';
import { getDiskUsage } from '../../services/CommonService';

class LayoutStore {
    @observable diskUsage = {
      total: 0,
      free: 0,
      used: 0,
    };

    @action async getDiskUsage() {
      const response = await getDiskUsage();
      if (response) {
        this.diskUsage = response;
      }
    }


}
export default LayoutStore;
