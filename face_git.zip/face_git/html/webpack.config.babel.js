const debug = process.env.NODE_ENV !== 'production';
const webpack = require('webpack');
const path = require('path');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const StyleLintPlugin = require('stylelint-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');

const CommonsChunkPlugin = webpack.optimize.CommonsChunkPlugin;
const UglifyJsPlugin = webpack.optimize.UglifyJsPlugin;

const distDir = 'www';
const chunked = `${!debug ? '[chunkhash].' : ''}`;

// Define shared/dev-only plugins
const devPlugins = [
  new (webpack.DefinePlugin)({
    'process.env': {
      NODE_ENV: JSON.stringify('development'),
    },
  }),
  new webpack.ProvidePlugin({
    $: 'jquery',
    jQuery: 'jquery',
    'window.jQuery': 'jquery',
  }),
  new CleanWebpackPlugin([distDir]),
  new HtmlWebpackPlugin({
    template: './public/index.pug',
  }),
  new ExtractTextPlugin({
    filename: '[name].bundle.css',
  }),
  new CommonsChunkPlugin({
    name: 'vendor',
    filename: '[name].bundle.js',
  }),

  new StyleLintPlugin({
    configFile: '.stylelintrc',
    context: 'src',
    failOnError: false,
    quiet: false,
  }),
];

// Define production-only plugins
const prodPlugins = [
  new (webpack.DefinePlugin)({
    'process.env': {
      NODE_ENV: JSON.stringify('production'),
    },
  }),
  new UglifyJsPlugin({
    mangle: true,
    sourceMap: true,
    comments: false,
    compress: {
      warnings: false,
      drop_console: true,
    },
  }),
];

// Set the plugins depending on environment
const plugins =
  debug
    ? devPlugins
    : devPlugins.concat(prodPlugins);

// Define modules that should included within specific chunks
const chunks = {
  app: ['./src/index'],
  // TODO: Edit these to reflect the vendor modules that should be included in another chunk
  vendor: ['babel-polyfill', 'react', 'react-dom', 'mobx', 'mobx-react'],
};

const config = {
  entry: chunks,

  output: {
    path: path.join(__dirname, distDir),
    filename: `[name].bundle.${chunked}js`,
    chunkFilename: `[id].bundle.${chunked}js`,
  },
  devServer: {
    contentBase: `./${distDir}`,
    port: 8000
  },
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: [
          /node_modules/,
          /mocks/,
          /.*\.test\.js/,
        ],
        use: [
          {
            loader: 'eslint-loader',
            options: {
              configFile: './.eslintrc',
            },
          },
        ],
        enforce: 'pre',
      },
      {
        test: /\.pug$/,
        exclude: /node_modules/,
        use: {
          loader: 'pug-loader',
        },
      },
      {
        test: /\.(js|jsx)$/,
        exclude: [
          /node_modules/,
          /mocks/,
        ],
        use: {
          loader: 'babel-loader',
        },
      },
      {
        test: /\.html$/,
        exclude: /index.html/,
        use: [
          'html-loader',
        ],
      },
      {
        test: /index.html$/,
        use: [
          'html-loader',
        ],
      },
      {
        test: /\.s?css$/,
        use: ExtractTextPlugin.extract({
          fallback: 'style-loader',
          use: [
            {
              loader: 'css-loader',
            },
            {
              loader: 'sass-loader',
              options: {
                sourceMap: true,
                includePaths: [
                  path.resolve(__dirname, './node_modules'),
                ],
                precision: 10,
              },
            },
          ],
        }),
      },
      {
        test: /\.(woff2?|ttf|eot|svg)$/,
        exclude: '/src/img/',
        use: [{
          loader: 'url-loader',
          options: {
            name: '[name].[ext]',
            outputPath: 'fonts/',
          },
        }],
      },
      {
        test: /\.svg$/,
        include: '/src/img/',
        use: [{
          loader: 'file-loader',
          options: {
            name: '[name].[ext]',
            outputPath: 'img/',
          },
        }],
      },
      {
        test: /\.(png|jpg|gif)$/,
        use: [
          'url-loader?limit=10000&name=img/[name].[ext]',
        ],
      },
      {
        test: /spacer.png$/,
        use: [
          'file-loader?name=img/[name].[ext]',
        ],
      },
    ],
  },
  resolve: {
    modules: [
      path.resolve(__dirname),
      'node_modules',
    ],
    extensions: [
      '.js',
      '.jsx',
    ],
  },
  plugins,
  devtool: 'source-map',
  watch: false,
  watchOptions: {
    poll: 1000,
    ignored: /node_modules/,
  },
  profile: false,
};

module.exports = config;
