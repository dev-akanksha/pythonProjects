# -*- coding: utf-8 -*-
from face_rekognition import FacialRekognition

fr = FacialRekognition()
# fr.delete_collection(fr.COLLECTION_ID)
# response = fr.describe_collection(fr.COLLECTION_ID)
# if response == None:
#     fr.create_collection(fr.COLLECTION_ID)
cpt = 0
while cpt < 1:
	img = fr.image_capture('123')
	print img
	cpt = cpt + 1


# fr.upload_to_s3('web/4345/4345.jpg', fr.BUCKET, '4345.jpg')
# index_response = fr.index_faces(img, fr.COLLECTION_ID, fr.BUCKET, fr.MAXFACES, fr.QUALITY_FILTER, fr.DETECTIONATTRIBUTE)
# for faceRecord in index_response:
#     faceID = faceRecord['Face']['FaceId']
#     print(faceRecord)
#     print('Face ID : ' + faceRecord['Face']['FaceId'])
#     print('Photo is uploaded to the collection :' + fr.COLLECTION_ID)