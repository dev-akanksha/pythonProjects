#!/usr/bin/python
# coding=utf-8
import sys
import json
import ast
import re, os
import cv2
from multiprocessing import Pool
from flask import Flask, jsonify, request
from collections import OrderedDict
from flask_cors import CORS
from face_rekognition import FacialRekognition
from speech_play import SpeechPlay
import time
from decimal import Decimal
import simplejson
import base64

fr = FacialRekognition()
speaker = SpeechPlay()
app = Flask(__name__,static_folder='web')
cors = CORS(app)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

#Camera Parameters
camera_index = 0
width = 1280
height = 720
x1 = None
y1 = None
x2 = None
y2 = None
name_person = None
employeeId = None
ImageId = None

@app.route('/api/createUser/', methods=['POST'])
def createUser():
    try:
        data = request.json
        empId = data.get("empId")
        emailId = data.get("emailId")
        headers = {"Content-Type": "application/json"}
        if fr.exist_user(empId, emailId):
            res =  {"message":"error","messageList":["Employee Id or email id already exist"]}
            return json.dumps(res), 200, headers
        else:
            # fr.delete_collection(fr.COLLECTION_ID)
            response = fr.describe_collection(fr.COLLECTION_ID)
            if response == None:
                fr.create_collection(fr.COLLECTION_ID)
            img = empId + '.jpg'
            imgpath = fr.IMG_FOLDER + empId + '/' + img
            fr.upload_to_s3(imgpath, fr.BUCKET, img, True)
            s3Img = 'https://s3.amazonaws.com/'+fr.BUCKET+'/'+img
            index_response = fr.index_faces(img, fr.COLLECTION_ID, fr.BUCKET, fr.MAXFACES, fr.QUALITY_FILTER, fr.DETECTIONATTRIBUTE)
            for faceRecord in index_response['FaceRecords']:
                faceID = faceRecord['Face']['FaceId']

            response = fr.update_index(fr.TABLENAME_DB,faceID, json.dumps(data), s3Img, json.dumps(index_response))
            res =  {"message":"success","messageList":["Employee added successfully."]}
    except Exception as e:
        res =  {"message":"error","messageList":[str(e)]}
    
    return json.dumps(res), 200, headers


@app.route('/api/imageCapture/', methods=['POST'])
def imageCapture():
    headers = {"Content-Type": "application/json"}
    try:
        data        = request.json
        empId       = data.get("empId")
        emailId     = data.get("emailId")
        isEdit      = data.get("isEdit")
        
        if isEdit == False:
            if fr.exist_user(empId, emailId):
                res =  {"message":"error","messageList":["Employee Id or email id already exist"]}
                return json.dumps(res), 200, headers

        img         = fr.image_capture(empId)

        if img is None:
            res         = {"message":"error","messageList":["Camera is not working"]}
        else:
            timestamp   = time.strftime("%Y%m%d-%H%M%S")
            res         = {"message":"success","messageList":[img+'?'+timestamp]}
        
    except Exception as e:
        res =  {"message":"error","messageList":[str(e)]}
    
    headers = {"Content-Type": "application/json"}

    return json.dumps(res), 200, headers


@app.route('/api/getAllUsers/', methods=['GET'])
def getAllUsers():
    try:        
        # fr.create_collection('frame_collection')
        response  = fr.getAllUsers(fr.TABLENAME_DB)
        res    = {"message":"success","messageList":simplejson.dumps(response)}
    except Exception as e:
        res =  {"message":"error","messageList":[str(e)]}
    
    headers = {"Content-Type": "application/json"}

    return json.dumps(res), 200, headers


@app.route('/api/deleteUser/<userid>/', methods=['DELETE'])
def deleteUser(userid):
    try:
        res = fr.deleteEmpDetail(userid,1)
        res    = {"message":"success","messageList":[res]}
    except Exception as e:
        res =  {"message":"error","messageList":[str(e)]}
    
    headers = {"Content-Type": "application/json"}

    return json.dumps(res), 200, headers

@app.route('/api/editUser/<userid>', methods=['PUT'])
def editUser(userid):
    try:
        data = request.json
        empId = data.get("empId")
        emailId = data.get("emailId")
        img = empId + '.jpg'
        img_captured = data.get("img_captured")
        s3Img = 'https://s3.amazonaws.com/'+fr.BUCKET+'/'+img

        resp = fr.deleteEmpDetail(userid, img_captured)

        if img_captured == 1:
            response = fr.describe_collection(fr.COLLECTION_ID)
            if response == None:
                fr.create_collection(fr.COLLECTION_ID)            
            imgpath = fr.IMG_FOLDER + empId + '/' + img
            fr.upload_to_s3(imgpath, fr.BUCKET, img, True)            
            index_response = fr.index_faces(img, fr.COLLECTION_ID, fr.BUCKET, fr.MAXFACES, fr.QUALITY_FILTER, fr.DETECTIONATTRIBUTE)
            for faceRecord in index_response['FaceRecords']:
                faceID = faceRecord['Face']['FaceId']
        else:
            faceID = resp['faceId']

        response = fr.update_index(fr.TABLENAME_DB,faceID, json.dumps(data), s3Img, json.dumps(index_response))
        res =  {"message":"success","messageList":["Employee updated successfully."]}
    except Exception as e:
        res =  {"message":"error","messageList":[str(e)]}
    
    headers = {"Content-Type": "application/json"}

    return json.dumps(res), 200, headers

@app.route('/api/getUserDataById/<empId>', methods=['GET'])
def getUserDataById(empId):
    try:
        response = fr.getUserByIdWithAttendance(empId)
        res    = {"message":"success","messageList":simplejson.dumps(response)}
    except Exception as e:
        res =  {"message":"error","messageList":[str(e)]}
    
    headers = {"Content-Type": "application/json"}

    return json.dumps(res), 200, headers

def get_api_response(frame, frame_count, enable_rekog=False):
    try:
        _, buff = cv2.imencode(".jpg", frame)
        img_bytes = bytearray(buff)
        print('yesss')
        response = fr.connection('lambda').invoke(
            FunctionName='facedetectfunction_prod',
            InvocationType='RequestResponse',
            Payload=bytes(json.dumps({
                'image_bytes': base64.b64encode(img_bytes),
            }),
        ))
        print('okkk')
        return json.load(response['Payload'])
    except Exception as e:
        print('here')
        print(e)
        return None    

def check_response_amount(result):
    try:
        global x1
        global y1
        global y2
        global x2
        global name_person
        global employeeId
        global ImageId
        x1 = None
        y1 = None
        x2 = None
        y2 = None
        name_person = None
        employeeId = None
        if result[0]['status']!='error':      
            resp = result[0]['message']
            if ImageId != resp['ImageId'] and resp['employeeId']!='':
                x1 = resp['x1']
                y1 = resp['y1']
                x2 = resp['x2']
                y2 = resp['y2']
                name_person = resp['name_person']
                employeeId = resp['employeeId']
                ImageId = resp['ImageId']
                polly = fr.connectToPolly()
                fr.speak(polly, "Hi, " + name_person)
                # addAttendance(ImageId, employeeId)
            print("DONE %s" + json.dumps(result))
    except Exception as e:
        print(e)
        return None

@app.route('/api/recognize/', methods=['GET'])
def recognize():
    try:
        capture_rate = 30
        cap = cv2.VideoCapture(0)
        pool = Pool(processes=4)
        frame_count = 0
        cascPath = "haarcascade_frontalface_default.xml"
        faceCascade = cv2.CascadeClassifier(cascPath)

        while True:
            ret, frame = cap.read()
            #Resize the captured image
            frame = cv2.resize(frame, (width, height))

            #If we cannot get the frame, exit
            if ret is False:
                print('error')
                break

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            # Detect faces in the image
            faces = faceCascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(30, 30)
            )


            #capture rate for AWS rekognition 
            if frame_count % capture_rate == 0 and len(faces) > 0:
                pool.apply_async(get_api_response, (frame, frame_count, True), callback=check_response_amount)      
            frame_count += 1
            
            if x1 != None and y1 != None and x2 != None and y2 != None:
                cv2.rectangle(frame, (x1-1, y1-1), (x2+1, y2+1), (255,0,0), 2)
                font = cv2.FONT_HERSHEY_COMPLEX_SMALL
                cv2.putText(frame, employeeId ,(x1,y1 + 80), font, 1,(0,0,0),2,cv2.LINE_AA)
                # cv2.putText(frame, ImageId ,(x1,y1 + 100), font, 1,(0,0,0),2,cv2.LINE_AA)
                cv2.putText(frame, name_person ,(x1,y1 + 120), font, 1,(0,0,0),2,cv2.LINE_AA)
            #Show the frame
            cv2.imshow('frame', frame)
            
            #Pressing Q for exit
            if cv2.waitKey(1) & 0xFF == ord('q'):
                response = 'forcefully quit.'
                break
        pool.close()
        pool.terminate()       
        #Release the camera and windows
        cap.release()
        cv2.destroyAllWindows()
        res    = {"message":"success","messageList":[response]}
        
    except Exception as e:
        res =  {"message":"error","messageList":[str(e)]}
    
    headers = {"Content-Type": "application/json"}

    return json.dumps(res), 200, headers 



@app.route('/api/getAttendance/<userid>', methods=['POST'])
def getAttendance():
    try:
        res = {}

        # Need to get data from dynamo DB
        

        res    = {"message":"success","messageList":[res]}
    except Exception as e:
        res =  {"message":"error","messageList":[str(e)]}
    
    headers = {"Content-Type": "application/json"}

    return json.dumps(res), 200, headers


if __name__ == '__main__':
    app.run(debug=True,host='localhost', port=5000)
