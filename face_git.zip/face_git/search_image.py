# -*- coding: utf-8 -*-
from face_rekognition import FacialRekognition

fr = FacialRekognition()
img = fr.image_capture()
fr.upload_to_s3(img, fr.BUCKET)
index_response = fr.search_faces_by_image(img, fr.COLLECTION_ID, fr.BUCKET, fr.MAXFACES, fr.THRESHOLD)
fr.delete_images(img, fr.BUCKET)
print(index_response)

for match in index_response['FaceMatches']:
    # print(match)
    matchFaceID = match['Face']['FaceId']
    print('Matched Face ID :' + "{}".format(matchFaceID))
    print('Similarity :' + "{:.2f}".format(match['Similarity']) + "%")
    print('The given ' + img + ' matches with: '+ match['Face']['ExternalImageId'])   