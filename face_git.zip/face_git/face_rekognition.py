# -*- coding: utf-8 -*-
import boto3
from botocore.exceptions import ClientError
import sys
import re
import cv2
import time
import os
from boto3.session import Session
import json
from multiprocessing import Pool
from boto3.dynamodb.conditions import Key, Attr
from datetime import datetime, timedelta
import simplejson
from playsound import playsound

class FacialRekognition:

    COLLECTION_ID           = 'image-collection-poc-v1'
    BUCKET                  = 'infopro-face-img'
    THRESHOLD               = 95
    MAXFACES                = 4
    AWS_ACCESS_KEY_ID       = 'AKIA2P2AOBTTEANSDZBN'
    AWS_SECRET_ACCESS_KEY   = '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'
    REGION_NAME             = 'us-east-1'
    QUALITY_FILTER          = 'AUTO'
    DETECTIONATTRIBUTE      = ['ALL']
    IMG_FOLDER              = 'web/'
    TABLENAME_DB            = 'employee_v1'
    TABLENAME_DB_ATTENDANCE = 'attendance_v1'
    TABLENAME_LOGS          = 'rekognition_logs_v1'
    TABLENAME_ADDENTANCE_LOGS  = 'attendance_logs_v1'
    EMPIDS                  = '10773,12747,13690,14482,12876,12652,12296,14101,14328,13535, 14254, 14067,12249'

    def connection(self, service):
        return boto3.client(service, aws_access_key_id = self.AWS_ACCESS_KEY_ID, aws_secret_access_key = self.AWS_SECRET_ACCESS_KEY, region_name = self.REGION_NAME)

    def db_connection(self, service):
        return boto3.resource(service, aws_access_key_id = self.AWS_ACCESS_KEY_ID, aws_secret_access_key = self.AWS_SECRET_ACCESS_KEY, region_name = self.REGION_NAME)

    def create_collection(self, collectionID):
        try: 
            client = self.connection('rekognition')
            response=client.create_collection(CollectionId=collectionID) 
            if(response['StatusCode'] == 200):
                return collectionID
            else:
                return None 
        except ClientError as e:            
            print("Boto3 Error : " + e.response['Error']['Code'])
            return None


    def delete_collection(self, collectionID):
        try:
            client = self.connection('rekognition')
            response =client.delete_collection(CollectionId=collectionID)
            if(response['StatusCode'] == 200):
                return collectionID
            else:
                return None 
        except ClientError as e:            
            print("Boto3 Error : " + e.response['Error']['Code'])
            return None

    def describe_collection(self, collectionID):
        try:
            client = self.connection('rekognition')
            response =client.describe_collection(CollectionId=collectionID)
            return response
        except ClientError as e:            
            print("Boto3 Error : " + e.response['Error']['Code'])
            return None

    def upload_to_s3(self, img_path, bucket, img, isDirRemove):
        try:
            client = self.connection('s3')
            response = client.upload_file(img_path, bucket, img)
            client.put_object_acl(Bucket=bucket, Key=img, ACL='public-read')
            rm_foldername = img_path.replace(img,'')
            os.remove(img_path)
            if isDirRemove:
                os.rmdir(rm_foldername)
            return response
        except ClientError as e:        
            print("Boto3 Error : " + e.response['Error']['Code'])
            return None


    def image_capture(self, empId):
        try:
            cam = cv2.VideoCapture(0)

            if cam is None or not cam.isOpened():
                return None
            else:
                ret, frame = cam.read()

                frame = cv2.resize(frame, (723,500))
                k = cv2.waitKey(0)

                if not ret:
                    cam.release() 

                img_name = empId+".jpg"
                folderPath = self.IMG_FOLDER + empId

                if not os.path.exists(folderPath):
                   os.mkdir(folderPath)
                
                cv2.imwrite(os.path.join(folderPath , img_name), frame)

                print("{} image captured!".format(img_name))

                cam.release() 

                return os.path.join(folderPath , img_name)
        except ClientError as e:            
            pathrint("Cam not working!!")
            return None

    def printResult(self, result):
        print(result)

    

    #adding faces to the collection
    def index_faces(self, img, collectionID, bucket, maxFaces, qualityFilter, detectionAttributes):      
        try:
            client = self.connection('rekognition')
            response = client.index_faces(
                CollectionId=collectionID,
                Image={
                    'S3Object':
                    {
                        'Bucket':bucket,
                        'Name':img,                                        
                    }
                },
                ExternalImageId=img,
                MaxFaces=maxFaces,
                QualityFilter=qualityFilter,
                DetectionAttributes=detectionAttributes
            )
            return response
        except ClientError as e:            
            print("Boto3 Error : " + e.response['Error']['Code'])
            return None
		               

    #searching faces from the collection      
    def search_faces_by_image(self, collectionID, bucket, maxFaces, threshold, img_bytes):    
        try: 
            client = self.connection('rekognition')
            response = client.search_faces_by_image(
                CollectionId=collectionID,
                Image={
                    'Bytes': img_bytes
                },
                FaceMatchThreshold=threshold,
                MaxFaces=maxFaces
            )
            return response
        except ClientError as e:
            print(e.response['Error'])
            return None

    def detect_faces(self, collectionID, bucket, img_bytes):    
        try: 
            client = self.connection('rekognition')
            response = client.detect_faces(
                Image={
                    'Bytes': img_bytes
                },
                Attributes=['ALL']
            )
            return response
        except ClientError as e:
            print("Boto3 Error : " + e.response['Error']['Code'])
            return None

    def delete_face_from_collection(self, faceid, collectionID):
        try:
            client = self.connection('rekognition')
            response=client.delete_faces(
                CollectionId=collectionID,
                FaceIds= [faceid]
            )
            return response
        except ClientError as e:            
            print("Boto3 Error : " + e.response['Error']['Code'])
            return None

    def delete_images(self, img, bucket):
        try:
            session = Session(aws_access_key_id=self.AWS_ACCESS_KEY_ID,aws_secret_access_key=self.AWS_SECRET_ACCESS_KEY)

            s3_resource = session.resource('s3')
            my_bucket = s3_resource.Bucket(bucket)

            response = my_bucket.delete_objects(
                Delete={
                    'Objects': [
                        {
                            'Key': img + '.jpg'
                        }
                    ]
                }
            )
        except ClientError as e:            
            print("Boto3 Error : " + e.response['Error']['Code'])
            return None
    
    # Save data into Db
    def update_index(self, tableName, faceId, userDetails, s3Url, metadata):
        try:
            client = self.db_connection('dynamodb')
            table = client.Table(tableName)
            data = json.loads(userDetails)
            response = table.put_item(
                Item={
                    'empId': int(data["empId"]),
                    'rekognitionId':faceId,
                    'emailid':data["emailId"],
                    'info':{
                        "userDetails" : userDetails,
                        's3Url': s3Url,
                        'metadata':metadata
                    }
                }
            )
            print("Item added")
            return response
        except ClientError as e:            
            print("Boto3 DB Error : Data not updated. try again. Error code:- " + e.response['Error']['Code'])
            return None


    def getAllUsers(self, tableName):
        try:
            client = self.db_connection('dynamodb')
            table = client.Table(tableName)
            result_item = []

            result_data = table.scan()

            result_item.extend(result_data['Items'])

            while 'LastEvaluatedKey' in result_data:
                result_data = my_table.scan(
                    ExclusiveStartKey=result_data['LastEvaluatedKey']
                )

                result_item.extend(result_data['Items'])

            return result_item
        except ClientError as e:            
            print("Boto3 DB Error :Please try again. Error code:- " + e.response['Error']['Code'])
            return None

    def exist_user(self,empId,emailId):
        print(emailId)
        client = self.db_connection('dynamodb')
        table = client.Table(self.TABLENAME_DB)
        # response = table.scan(
        #     FilterExpression=Attr("empId").eq(int(empId))
        # )
        response = table.scan(
            FilterExpression=Attr("empId").eq(int(empId)) | Attr("emailid").eq(emailId)
        )
        return response["Count"] > 0

    def deleteEmpDetail(self, empId, img_captured):
        result = self.getUserById(empId)
        faceId = result['Item']['rekognitionId']
        client = self.db_connection('dynamodb')
        table = client.Table(self.TABLENAME_DB)
        response = table.delete_item(
                Key={'empId': int(empId)}
            )
        response['faceId'] = faceId
        if img_captured == 1:
            if response['ResponseMetadata']['HTTPStatusCode'] is 200:
                response2 = self.delete_images(empId, self.BUCKET)
                if faceId!= '':
                    response3 = self.delete_face_from_collection(faceId,self.COLLECTION_ID)
        return response

    def getUserById(self, empId):
        client = self.db_connection('dynamodb')
        table = client.Table(self.TABLENAME_DB)
        response = table.get_item(
            Key={
                'empId': int(empId)
            }
        )
        return response

    def getUserByIdWithAttendance(self, empId):
        client = self.db_connection('dynamodb')
        table = client.Table(self.TABLENAME_DB)
        response = table.get_item(
            Key={
                'empId': int(empId)
            }
        )

        rekgId = response['Item']['rekognitionId']

        table = client.Table(self.TABLENAME_DB_ATTENDANCE)
        attendances = table.scan(
            FilterExpression=Attr("empId").eq(int(empId)) & Attr('rekognitionId').eq(rekgId)
        )
        
        if attendances["Count"] > 0:            
            response['Item']['attendance'] = attendances['Items']

        # print(response)
        return response

    def addLogs(self, matchedfaceId, empId, metadata, matchFound):
        try:
            client = self.db_connection('dynamodb')
            table = client.Table(self.TABLENAME_LOGS)

            now = datetime.now()
            today = now.strftime("%d/%m/%Y")
            currenttime = now.strftime("%H:%M:%S")
            timestamp   = now.strftime("%Y%m%d%H%M%S")
    
            response = table.put_item(
                Item={
                    'id': int(timestamp),
                    'empId': int(empId),
                    'matchedfaceId':matchedfaceId,
                    'date':today,
                    'time': currenttime,
                    'metadata':metadata,
                    'matchFound':matchFound
                }
            )
            return response
        except ClientError as e:            
            print("Boto3 DB Error : Data not updated. try again. Error code:- " + e.response['Error']['Code'])
            return None


    def connectToPolly(self):
        polly_client = boto3.Session(aws_access_key_id=self.AWS_ACCESS_KEY_ID, aws_secret_access_key=self.AWS_SECRET_ACCESS_KEY, region_name=self.REGION_NAME).client('polly')
        return polly_client

    def speak(self,polly, text, format='mp3', voice='Emma'):
        resp = polly.synthesize_speech(OutputFormat=format, Text=text, VoiceId=voice)
        soundfile = open('/tmp/sound.mp3', 'wb')
        soundBytes = resp['AudioStream'].read()
        soundfile.write(soundBytes)
        soundfile.close()
        playsound('/tmp/sound.mp3')  # Works only on Mac OS, sorry
        os.remove('/tmp/sound.mp3')